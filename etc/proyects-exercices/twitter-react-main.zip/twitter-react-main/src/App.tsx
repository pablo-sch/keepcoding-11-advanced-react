// import LoginPage from "./pages/auth/login-page";
import TweetsPage from "./pages/tweets/tweets-page";
// import NewTweetPage from "./pages/tweets/new-tweet-page";
import { Navigate, Route, Routes } from "react-router";
import Layout from "./components/layout/layout";
import RequireAuth from "./pages/auth/require-auth";
import TweetPage from "./pages/tweets/tweet-page";
import { lazy, Suspense } from "react";

const LoginPage = lazy(() => {
  return import("./pages/auth/login-page").then((result) => {
    console.log(result);
    return result;
  });
});

const NewTweetPage = lazy(() => import("./pages/tweets/new-tweet-page"));

function App() {
  return (
    <Routes>
      <Route
        path="/login"
        element={
          <Suspense fallback={<div>Loading login page...</div>}>
            <LoginPage />
          </Suspense>
        }
      />
      <Route path="/tweets" element={<Layout />}>
        <Route index element={<TweetsPage />} />
        <Route path=":tweetId" element={<TweetPage />} />
        <Route
          path="new"
          element={
            <RequireAuth>
              <Suspense fallback={<div>Loading new tweet page...</div>}>
                <NewTweetPage />
              </Suspense>
            </RequireAuth>
          }
        />
      </Route>
      <Route path="/" element={<Navigate to="/tweets" />} />
      <Route path="/not-found" element={<div>404 | Not Found</div>} />
      <Route path="*" element={<Navigate to="/not-found" />} />
    </Routes>
  );
}

export default App;
