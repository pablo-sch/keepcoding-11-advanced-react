import "./login-page.css";
import {
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
} from "react";
import Button from "../../components/ui/button";
import { login } from "./service";
import { useAuth } from "./context";
import FormField from "../../components/ui/form-field";
import { useLocation, useNavigate } from "react-router";
import { AxiosError } from "axios";
import { createPortal } from "react-dom";
import copyStyles from "../../utils/copyStyles";

function LoginPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { onLogin } = useAuth();
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
  });
  const [error, setError] = useState<{ message: string } | null>(null);
  const [isFetching, setIsFetching] = useState(false);
  // const firstTime = useRef(true);
  const timeoutRef = useRef<number | null>(null);

  useEffect(() => {
    timeoutRef.current = setTimeout(() => {
      console.log("Timeout", timeoutRef.current);
    }, 20000);
    console.log("creating timeout", timeoutRef.current);

    return () => {
      if (timeoutRef.current) {
        clearInterval(timeoutRef.current);
      }
    };
    // console.log("Effect");
    // if (firstTime.current) {
    //   console.log("First time");
    //   firstTime.current = false;
    // }
  }, []);

  const { username, password } = credentials;
  const isDisabled = !username || !password || isFetching;

  function handleChange(event: ChangeEvent<HTMLInputElement>) {
    setCredentials((prevCredentials) => ({
      ...prevCredentials,
      [event.target.name]: event.target.value,
    }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      if (timeoutRef.current) {
        console.log("clean timeout", timeoutRef.current);
        clearInterval(timeoutRef.current);
      }
      setIsFetching(true);
      await login(credentials);
      onLogin();
      // Navigate to the page in state.from
      const to = location.state?.from ?? "/";
      navigate(to, { replace: true });
    } catch (error) {
      if (error instanceof AxiosError) {
        setError({
          message: error.response?.data?.message ?? error.message ?? "",
        });
      }
    } finally {
      setIsFetching(false);
    }
  }

  return (
    <div className="login-page">
      <h1 className="login-page-title">Log in to Twitter</h1>
      <form onSubmit={handleSubmit}>
        <FormField
          type="text"
          name="username"
          label="phone, email or username"
          value={username}
          onChange={handleChange}
        />
        <FormField
          type="password"
          name="password"
          label="password"
          value={password}
          onChange={handleChange}
        />
        <Button
          type="submit"
          $variant="primary"
          disabled={isDisabled}
          className="login-form-submit"
        >
          Log in
        </Button>
      </form>
      {error && (
        <div
          className="login-page-error"
          role="alert"
          onClick={() => {
            setError(null);
          }}
        >
          {error.message}
        </div>
      )}
    </div>
  );
}

function LoginPagePortal() {
  const portalContainer = useRef<HTMLDivElement>(document.createElement("div"));

  useEffect(() => {
    portalContainer.current.className = "container";

    const externalWindow = window.open("", "", "width=600, height=500");

    if (externalWindow) {
      externalWindow.document.body.appendChild(portalContainer.current);
      copyStyles(window.document, externalWindow.document);
    }

    return () => {
      if (externalWindow) {
        externalWindow.close();
      }
    };
  }, []);

  return createPortal(<LoginPage />, portalContainer.current);
}

export default LoginPagePortal;
