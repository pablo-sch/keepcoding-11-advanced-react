export interface Credentials {
  username: string;
  password: string;
}

export interface Login {
  accessToken: string;
}
