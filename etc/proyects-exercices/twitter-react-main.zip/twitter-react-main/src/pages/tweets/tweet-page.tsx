import { useNavigate, useParams } from "react-router";
import Page from "../../components/layout/page";
import { useEffect, useState } from "react";
import type { Tweet } from "./types";
import { getTweet } from "./service";
import { AxiosError } from "axios";

function TweetPage() {
  const params = useParams();
  const [tweet, setTweet] = useState<Tweet | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!params.tweetId) {
      return;
    }
    getTweet(params.tweetId)
      .then((tweet) => setTweet(tweet))
      .catch((error) => {
        if (error instanceof AxiosError) {
          if (error.status === 404) {
            navigate("/not-found", { replace: true });
          }
        }
      });
  }, [params.tweetId, navigate]);

  return (
    <Page title="Tweet detail">
      Tweet detail {params.tweetId}-{tweet?.content}
    </Page>
  );
}

export default TweetPage;
