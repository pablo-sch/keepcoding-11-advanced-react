// interface User {
//   name: string;
//   username: string;
// }

import { z } from "zod";

// export interface Tweet {
//   id: number;
//   userId: number;
//   content: string;
//   updatedAt: string;
//   user: User;
//   likes: unknown[];
// }

const UserSchema = z.object({
  name: z.string(),
  username: z.string(),
});

// type User = z.infer<typeof UserSchema>;

export const TweetSchema = z.object({
  id: z.number(),
  userId: z.number(),
  content: z.string(),
  updatedAt: z.string(),
  user: UserSchema,
  likes: z.array(z.unknown()),
});

export type Tweet = z.infer<typeof TweetSchema>;

export const TweetsSchema = z.array(TweetSchema);
