import "./tweets-page.css";
import { getLatestTweets } from "./service";
import { useEffect, useState } from "react";
import type { Tweet } from "./types";
import Button from "../../components/ui/button";
import TweetItem from "./tweet-item";
import Page from "../../components/layout/page";
import { Link } from "react-router";

const EmptyList = () => (
  <div className="tweets-page-empty">
    <p>Be the first one!</p>
    <Button $variant="primary">Create tweet</Button>
  </div>
);

function TweetsPage() {
  const [tweets, setTweets] = useState<Tweet[]>([]);

  useEffect(() => {
    async function getTweets() {
      const tweets = await getLatestTweets();
      setTweets(tweets);
    }
    getTweets();
  }, []);

  return (
    <Page title="What are you thinking?!">
      <div className="tweets-page">
        {tweets.length ? (
          <ul>
            {tweets.map((tweet) => (
              <li key={tweet.id}>
                <Link to={`/tweets/${tweet.id}`}>
                  <TweetItem tweet={tweet} />
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <EmptyList />
        )}
      </div>
    </Page>
  );
}

export default TweetsPage;
