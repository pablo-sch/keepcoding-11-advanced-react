import "./layout.css";
import Footer from "./footer";
import Header from "./header";
import { Outlet } from "react-router";
import ErrorBoundary from "../errors/error-boundary";

function Layout() {
  return (
    <div className="layout">
      <Header />
      <main className="layout-main">
        <ErrorBoundary>
          <Outlet />
        </ErrorBoundary>
      </main>
      <Footer />
    </div>
  );
}

export default Layout;
