import "./footer.css";

function Footer() {
  return <footer className="footer">@2025 Keepcoding</footer>;
}

export default Footer;
